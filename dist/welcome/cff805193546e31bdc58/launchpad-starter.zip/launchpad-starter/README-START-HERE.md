# Launchpad Starter Kit

A tiny static-site generator for a home page, free-signup pages, thank-you pages and freebie pages.

## Use it with the Launchpad master prompt
1. Put this folder in your project (or give it to Claude).
2. Tell Claude to edit `pages.json` (your site text and signup pages) and `freebies.json` (the freebie content), then run `python3 build.py`.
3. The finished site is in the `dist/` folder. Upload `dist/` to a free host (Cloudflare Workers/Pages static assets).

## Files
- `pages.json`: site name, home page text, one entry per signup page. `form_token` is the signup form token from your email tool.
- `freebies.json`: the freebie content. Each key matches a page slug. Use `items` for a checklist.
- `build.py`: builds `dist/`.
- `freebies.py`: renders freebie pages.
- `assets/style.css`: styles. `assets/rob.jpg`: replace with your photo (keep the file name).

## Notes
- Replace every [BRACKET] with your own words. Don't invent facts or testimonials.
- Pages under `/thanks/` and `/r/` are marked noindex so search engines skip them.
- To hide a signup page, add `"hidden": true` to it.
- PDF versions are optional. Put PDFs in `assets/downloads/<slug>.pdf` and the page will show a download button.
